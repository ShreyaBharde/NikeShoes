function Success(){
    return<>
    <div>
    <img style={{width:'50%',marginLeft:'400px'}} src="https://ruperhat.com/wp-content/uploads/2020/06/Paymentsuccessful21.png" alt="success"></img>

    </div>
    </>
}
export default Success